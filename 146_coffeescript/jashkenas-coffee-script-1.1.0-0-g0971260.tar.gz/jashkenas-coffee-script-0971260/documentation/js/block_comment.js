/*
CoffeeScript Compiler v1.1.0
Released under the MIT License
*/