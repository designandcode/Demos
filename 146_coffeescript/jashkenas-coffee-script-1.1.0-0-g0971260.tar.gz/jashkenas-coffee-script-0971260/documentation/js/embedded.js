var hi;
hi = function() {
  return [document.title, "Hello JavaScript"].join(": ");
};