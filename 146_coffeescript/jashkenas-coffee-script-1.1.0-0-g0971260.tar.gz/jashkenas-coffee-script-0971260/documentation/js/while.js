var lyrics, num;
if (this.studyingEconomics) {
  while (supply > demand) {
    buy();
  }
  while (!(supply > demand)) {
    sell();
  }
}
num = 6;
lyrics = (function() {
  var _results;
  _results = [];
  while (num -= 1) {
    _results.push(num + " little monkeys, jumping on the bed.    One fell out and bumped his head.");
  }
  return _results;
})();