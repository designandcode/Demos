Amplify is a set of components for data management and application communication.

For more information or a distribution with minified files see http://amplifyjs.com.

See each directory for docs regarding usage and examples for each component.

amplify.min.js contains all of the components packaged into a single file.
Use this file if you are planning on using all of the components.
