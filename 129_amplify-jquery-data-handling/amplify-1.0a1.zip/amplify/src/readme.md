Amplify is a set of components for data management and application communication.

For more information or a distribution with minified files see the [Amplify site](http://amplifyjs.com).

See each directory for docs regarding usage and examples for each component.
