﻿// Plugin created by Brock Nusser - http://mlamenu.blogspot.com/

$(function () {
	var collapse = new Boolean();
	//setup - all values in pixels
	var navWidth = 180;
	var ulIndent = 15;
	collapse = true;
	//end setup
	
	$('#nav').css('width', navWidth + 'px');
	$('#nav ul').css('width', navWidth + 'px');
	$('#nav ul').css('margin-left', ulIndent + 'px');


	$('#nav a').each(function () {
		var level = $(this).parents('ul').length;
		var liWidth = navWidth - (ulIndent * level);
		$(this).parent('li').css('width', liWidth + 'px');
	});
	
	//Required Section
    var slideSpeed = 'normal'; // 'slow', 'normal', 'fast', or miliseconds 
	$('#nav a').each(function () {
        var thisHref = $(this).attr('href')
		if ((window.location.pathname.indexOf(thisHref) == 0) || (window.location.pathname.indexOf('/' + thisHref) == 0)) {
            $(this).addClass('Current');
        }
    });
    
	$('.Current').parent('li').children('ul').show();
    $('.Current').parents('ul').show();
    
    $('#nav a').click(function () {
        if ($(this).parent('li').children('ul').html() != null) {
			if(collapse){$(this).parent('li').parent('ul').children('li').children('ul').hide(slideSpeed);}
            if ($(this).parent('li').children('ul').css('display') == "block") {
                $(this).parent('li').children('ul').hide(slideSpeed);
            } else {
                $(this).parent('li').children('ul').show(slideSpeed);
            }
            return false;
        }
	
    });

    $('#nav li').click(function () {
        if ($(this).children('a').length == 0) {
            if ($(this).children('ul').html() != null) {
                $(this).parent('ul').children('li').children('ul').hide(slideSpeed);
                if ($(this).children('ul').css('display') == "block") {
                    $(this).children('ul').hide(slideSpeed);
                } else {
                    $(this).children('ul').show(slideSpeed);
                }
            }
        } 
    });
	//End Required Section

	//Optional Section - Show Carrots
    var imgOffClosed = "url(images/imgOffClosed.gif) no-repeat 5px ";
    var imgOnClosed = "url(images/imgOnClosed.gif) no-repeat 5px ";
    var imgOnOpen = "url(images/imgOnOpen.gif) no-repeat 5px ";
    var charBeforeLB = 23; //characters before line break - you must calculate this - based on font-size and LI width;
	var paddingBig = 12; //push carrot arrow down (in pixels) when no there is a line break in the LI
    var paddingSmall = 8;  //push carrot arrow down (in pixels) when no there is no line break in the LI
    var maxLIHeight = 50; // max height of LI when list is closed

    $('#nav > li').each(function () {

        var childText = $(this).children('a').text();
        var topPadding = paddingBig;
        if (childText.length < charBeforeLB) { topPadding = paddingSmall; }
        if ($(this).height() < maxLIHeight) {//list is closed

            if ($(this).children('a').attr('class') == "Current") {
                $(this).css('background', imgOnClosed + topPadding + "px");
            } else {
                $(this).css('background', imgOffClosed + topPadding + "px");
            }

            if ($(this).children('a').attr('class') != "Current") {
                $(this).hover(function () {
                    if ($(this).height() < maxLIHeight) { 
						$(this).css('background', imgOnClosed + topPadding + "px"); 
					}
                },
                function () {
                    if ($(this).height() < maxLIHeight) { 
						$(this).css('background', imgOffClosed + topPadding + "px"); 
					}
                });
            }
        }
        else {// list is open
            $(this).css('background', imgOnOpen + topPadding + "px");
        }

        $(this).children('a').click(function () {
            $('#nav > li').each(function () {
                var childText = $(this).children('a').text();
                var topPadding = paddingBig;
                if (childText.length < charBeforeLB) { topPadding = paddingSmall; }
                if ($(this).children('a').attr('class') == 'Current') {
                    $(this).css('background', imgOnClosed + topPadding + "px");
                } else {
                    $(this).css('background', imgOffClosed + topPadding + "px");
                }
            });
            var liHeight = $(this).parent('li').height();
            if ($(this).parent('li').children('ul').length > 0) {
                if (liHeight < maxLIHeight) { 
					$(this).parent('li').css('background', imgOnOpen + topPadding + "px");
				} else { 
					$(this).parent('li').css('background', imgOnClosed + topPadding + "px"); 
				}
            }

        });
    });
	//End Optional Section
});