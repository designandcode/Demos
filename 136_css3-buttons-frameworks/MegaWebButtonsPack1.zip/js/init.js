$(function(){ 
	$('.btn').append($('<span />').addClass('helper'));
});
