$(function(){

	$('form').idealForms();
	
});
